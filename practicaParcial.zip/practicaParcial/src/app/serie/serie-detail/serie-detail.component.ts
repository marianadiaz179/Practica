import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SerieDetail } from '../serie-detail';
import { SerieService } from '../serie.service';

@Component({
  selector: 'app-serie-detail',
  templateUrl: './serie-detail.component.html',
  styleUrls: ['./serie-detail.component.css']
})
export class SerieDetailComponent implements OnInit {

  serieId!: string;
  @Input() serieDetail!: SerieDetail;

  constructor(
    private route: ActivatedRoute,
    private serieService: SerieService
  ) {}

  getSerie(){
    this.serieService.getSerie(this.serieId).subscribe(serie=>{
      this.serieDetail = serie;
    })
  }

  ngOnInit() {
    if(this.serieDetail === undefined){
      this.serieId = this.route.snapshot.paramMap.get('id')!
      if (this.serieId) {
        this.getSerie();
      }
    }
  }
}


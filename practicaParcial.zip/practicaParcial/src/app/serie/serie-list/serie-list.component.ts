import { Component, OnInit } from '@angular/core';
import { SerieDetail } from '../serie-detail';
import { SerieService } from '../serie.service';

@Component({
  selector: 'app-serie-list',
  templateUrl: './serie-list.component.html',
  styleUrls: ['./serie-list.component.css']
})
export class SerieListComponent implements OnInit {
  series: Array<SerieDetail> = [];
  selectedSerie!: SerieDetail;
  selected: boolean = false;
  public average: number = 0;

  constructor(private serieService: SerieService) { }

  getSeries(){
    this.serieService.getSeries().subscribe((series)=>{
      this.series =series;
      this.getAvg();
    });
  }

  selectSerie(serie: SerieDetail){
    this.selectedSerie = serie;
    this.selected = true;
  }

  getAvg()
  {
    for( let i of this.series)
    {
      this.average += i.seasons;
    }

    this.average = this.average/this.series.length;
  }

  ngOnInit() {
    this.getSeries();
  }

}
